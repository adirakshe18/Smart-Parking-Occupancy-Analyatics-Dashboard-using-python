from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import webbrowser, threading, time, os

ROOT = Path(__file__).resolve().parent
PORT = 8765
os.chdir(ROOT)

class Handler(SimpleHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

server = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
url = f"http://127.0.0.1:{PORT}/index.html"

threading.Timer(0.7, lambda: webbrowser.open(url)).start()
print("Smart Parking Occupancy Analytics")
print(f"Running at {url}")
print("Press Ctrl+C to stop.")

try:
    server.serve_forever()
except KeyboardInterrupt:
    pass
finally:
    server.server_close()
