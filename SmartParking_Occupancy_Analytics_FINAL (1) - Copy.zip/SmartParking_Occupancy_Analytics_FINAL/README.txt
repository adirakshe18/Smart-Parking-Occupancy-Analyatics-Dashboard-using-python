SMART PARKING OCCUPANCY ANALYTICS - FINAL
=============================================

Professional 2D parking dashboard based on the supplied visual reference.

Capacity:
- Lot A: A-01 to A-20
- Lot B: B-01 to B-20
- Total: 40

Controls:
- Vehicle Entry: automatic plate/type/slot simulation and animated route
- Vehicle Exit: parked vehicle selection, fee calculation and animated route
- Multiple vehicle animations can run independently
- Barriers open and close during entry/exit
- Rates and reset use Safety Code: 0011
- Reports exports CSV
- No external packages are required

Run:
1. Install Python 3 if it is not already installed.
2. Open this folder in Cursor.
3. Terminal:
   python run.py
4. Chrome opens automatically.

Do not open index.html directly if you want the launcher behavior.

Animation behavior:
- Vehicles move at a normal, human-observable parking-facility speed.
- Entry barrier opens first, vehicle waits briefly, then passes.
- Entry barrier closes only after the vehicle clears the gate.
- Exit barrier follows the same open -> wait -> pass -> clear -> close sequence.
- Entry and exit vehicles use independent animation state, so multiple vehicles can move without a global animation lock.
